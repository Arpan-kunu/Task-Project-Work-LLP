const mongoose = require('mongoose')
const { Schema } = mongoose

const dropdownSchema = new Schema({
    file : {
        type : String
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    }
})

const Dropdown = mongoose.model('Dropdown',dropdownSchema)

module.exports = Dropdown