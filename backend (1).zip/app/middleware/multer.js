const multer = require('multer')

// const storage = multer.diskStorage({
//     destination:function(req,file,cb){
//         cb(null,'uploads/')
//     },
//     filename : function(req,file,cb){
//         cb(req.file,file.originalname.split(' ').join('-'))
//     }
// })
const upload = multer({dest:'upload/'})
const type = upload.single('file')

module.exports={
    type
}