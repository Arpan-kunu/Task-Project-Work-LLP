const User = require('../models/User')
const jwt = require('jsonwebtoken')

const authenticateUser = (req,res,next) => {
    const token =  req.header('Authorization').split(' ')[1]
    let tokenData 
    try {
        tokenData = jwt.verify(token,'alpha7575')
        User.findById(tokenData._id)
           .then((user)=>{
             req.user = user
             next()
           })
           .catch((err)=>{
            res.json(err)
           })
    } catch (error) {
        res.json(error.message)
    }
}

module.exports = {
    authenticateUser
}