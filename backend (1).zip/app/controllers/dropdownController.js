const Dropdown = require('../models/dropdown')
const dropdownController = {}

dropdownController.create = (req,res) => {
    const body = req.body
    // body.userId = req.user.id
    // body.file = req.file
    const dropdown = new Dropdown(body)
    dropdown.save()
            .then((dropdown)=>{
                res.json(dropdown)
            })
            .catch((err)=>{
                res.json(err)
            })
}
dropdownController.list = (req,res) => {
    console.log({"userId":req.user.id})
    Dropdown.find({"userId":req.user.id})
            .then((dropdown)=>{
                res.json(dropdown)
            })
            .catch((err)=>{
                res.json(err)
            })
}
module.exports = dropdownController