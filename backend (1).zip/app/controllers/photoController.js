const express = require("express");
const router = express.Router();
const multer = require("multer");
const moment = require("moment");
const dropdownModels = require("../models/dropdown")

var imgConfig = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, "./upload");
    },
    filename: (req, file, callback) => {
        callback(null, `image-${file.originalname}`)
    }
})

const isImage = (req, file, callback) => {
    if (file.mimetype.startsWith("image")) {
        callback(null, true)
    } else {
        callback(null, Error("only image is allowed"))
    }
}

var upload = multer({
    storage: imgConfig,
    fileFilter: isImage
})

router.post("/uploadImg", upload.single("photo"), async(req, res) => {
    // const {fname}=req.body;
    const { filename } = req.file;

    console.log(filename);
 

    const Id = "63eb694bf405fabc77bc15e6";

    const photoUpload = {
        file: filename,
        userId: Id
    }
    try {
        const newPhotoUpload = new dropdownModels(photoUpload);
        await newPhotoUpload.save();

        res.status(201).json({
            data:newPhotoUpload
        })

    } catch (error) {
        res.status(401).send(error);
    }

})

module.exports = router;