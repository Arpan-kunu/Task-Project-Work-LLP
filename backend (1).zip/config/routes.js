const express = require('express')
const router = express.Router()
const userControllers = require('../app/controllers/userController')
const dropdownController = require('../app/controllers/dropdownController')
const {authenticateUser} = require('../app/middleware/authentication')
const { type } = require("../app/middleware/multer")

router.post('/api/register',userControllers.register)
router.post('/api/login',userControllers.login)
router.get('/api/account',authenticateUser,userControllers.account)

router.post('/api/dropdown/create',authenticateUser,type,dropdownController.create)
router.get('/api/dropdown/list',authenticateUser,dropdownController.list)


// Route to handle image upload
// router.post('/api/images', type, (req, res) => {
//   // Create a new Image model from the uploaded image
//   const image = new Image({
//     filename: req.file.originalname,
//     file: req.file.buffer
//   });

//   // Save the image to the database
//   image.save()
//     .then(() => {
//       res.send({ success: true, message: 'Image uploaded successfully.' });
//     })
//     .catch((error) => {
//       res.status(500).send({ success: false, message: 'Error uploading image.', error: error });
//     });
// });


module.exports = router 