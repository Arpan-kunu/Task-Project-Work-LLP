const express = require('express')
const app = express()
const cors = require('cors')
const path = require('path')
const PORT = 3077
const configureDB = require('./config/database')
const router = require('./config/routes')
const photoController = require('./app/controllers/photoController'); 


app.use(express.json())
app.use(cors())
configureDB()
app.use(router)
app.use('/uploads',express.static('uploads'))

app.use(express.static(path.join(__dirname, 'client/build')))
app.get('*', (req,res) =>{
    res.sendFile(path.join(__dirname+'/client/build/index.html'))
})

app.use('/photo',photoController);


app.listen(PORT,()=>{
    console.log('server running on port :',PORT)
})
