import React, { useState } from 'react'
import axios from 'axios'
import { TextField, FormControl, Typography, Button} from '@material-ui/core'
import LoginSharpIcon from '@mui/icons-material/LoginSharp';
import '../CSS/Registration.css'
import { useNavigate } from 'react-router-dom';
import {message} from 'antd'

const Login = () => {
  const Navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')


  const handleChange = (e) => {
   if (e.target.name === "email") {
      setEmail(e.target.value)
    } else if (e.target.name === "password") {
      setPassword(e.target.value)
    }
  }
  const handleSubmit = (e) => {
    e.preventDefault()
    const form = {
      email,
      password
    }
    console.log('1', form)
    axios.post('http://localhost:3077/api/login', form)
      .then((response) => {
        const result = response.data
        console.log('2', result)
        if(result.hasOwnProperty('errors')){
          message.error(result.message)
         }else{
             message.success('sucessfully logged In')
             localStorage.setItem('token',result.token)
             Navigate('/dashboard')
         }
      
      })
      .catch((err) => {
        alert(err.message)
      })
  }
  return (
    <div className='Registration'>
      <div>
        < LoginSharpIcon />
        <br />
        <Typography variant="h4" component="h4">
          Login with us
        </Typography>

      </div >
      <form className='form' onSubmit={handleSubmit}>
        <FormControl >
          <TextField type="text" label="Email" placeholder="Please Enter Your Email" value={email} name="email" onChange={handleChange} />
          <br />
          <TextField type='password' label="Password" placeholder="Please Enter Your Password" value={password} name="password" onChange={handleChange} />
          <br />

          <div className='Button'>
            <Button type="submit">Login</Button>
          </div>
        </FormControl>
        <p>If you are not Register <a href='/register'> click here </a> to go register page</p>
      </form>
    </div>
  )
}

export default Login