import React from 'react'
import { Typography } from '@material-ui/core'
import '../CSS/Home.css'

const Home = () => {
    return (
        <div className='Home'>
            <Typography variant="h4" component="h4">
                Welcome to our website
            </Typography>
            <p style={{"margin-top": "27px"}}>If you are not Register <a href='/register'> click here </a> to go register page</p>
            <p style={{"margin-top": "27px"}}>If you are Already Register <a href='/login'> click here </a> to go login page</p>
        </div>
    )
}

export default Home