import React from 'react'
import { Typography,Button } from '@material-ui/core'
import '../CSS/Dashboard.css'
import AccountCircleSharpIcon from '@mui/icons-material/AccountCircleSharp';
import ExitToAppSharpIcon from '@mui/icons-material/ExitToAppSharp';
import NoteAltSharpIcon from '@mui/icons-material/NoteAltSharp';
import { useNavigate } from 'react-router-dom';
import swal from 'sweetalert';


const Dashboard = () => {
    const Navigate = useNavigate()

    const handleClick = () => {
     Navigate('/account')
    }
    const handleLogout  = () => {
      swal({
        title: "Are you sure?",
        text: "Are you sure that you want to logged out?",
        icon: "warning",
        dangerMode: true,
      })
      .then(willDelete => {
        if (willDelete) {
          swal("logout!", "redirecting go to home page", "success");
          localStorage.removeItem('token')
          Navigate('/')
        }
      });
    
    }
  return (
    <div className='Dashboard'>
        <Typography variant="h4" component="h4">
          Dashboard
        </Typography>
        <div className='Account'>
        <Button onClick={handleClick}><AccountCircleSharpIcon/>Account</Button>
        <Button><NoteAltSharpIcon/>Notepad</Button>
        <Button onClick={handleLogout}><ExitToAppSharpIcon />LOGOUT</Button>
        </div>
    </div>
  )
}

export default Dashboard