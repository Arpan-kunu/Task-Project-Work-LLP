import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Typography, Button } from '@material-ui/core'
import '../CSS/Account.css'
import { message } from 'antd'
import { useNavigate } from 'react-router-dom'

const Account = () => {
    const Navigate = useNavigate()
    const [data, setData] = useState([])
    const [file, setFile] = useState()
    const [upload, setUpload] = useState()

    useEffect(() => {
        axios.get('http://localhost:3077/api/account', {
            headers: {
                "Authorization": localStorage.getItem('token')
            }
        })
            .then((response) => {
                const result = response.data
                setData(result)
            })
            .catch((err) => {
                message.error(err.message)
            })
    }, [])
    const handleClick = (e) => {
        Navigate('/dashboard')
    }
    function handleChange(event) {
        setFile(event.target.files[0])
    }
    const id = data._id
    console.log(id)
    const handleSubmit = (e) => {
        e.preventDefault()
        const formData ={
            file,
            userId : id
        }
        
        axios.post('http://localhost:3077/api/dropdown/create',{
            headers: {
                "Authorization": localStorage.getItem('token')
            },formData
        })
          .then((response) => {
                const result = response.data
                console.log(result)
                setUpload(result)
            })
          .catch((err) => {
                message.error(err.message)
            })
    }
    return (
        <div className='Details'>
            <button type="button" class="btn btn-secondary" onClick={handleClick}>Go Back</button>
            <Typography variant="h4" component="h4">
                Account Details
            </Typography>

            <div className='Details'>
                <form onSubmit={handleSubmit}>
                    <h1>React File Upload</h1>
                    <input type="file" onChange={handleChange} />
                    <button type="submit">Upload</button>
                </form>
                <Typography variant="h6" component="h6">
                    Name - {data.name}
                </Typography>
                <Typography variant="h5" component="h5">
                    Email - {data.email}
                </Typography>
            </div>
        </div>
    )
}

export default Account