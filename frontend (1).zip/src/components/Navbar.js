import React from 'react'
import Registration from './Registration'
import Login from './Login'
import { Route, Routes } from 'react-router-dom'
import Home from './Home'
import Dashboard from './Dashboard'
import Account from './Account'
import Logout from './Logout'
import Private from '../Private/Private'


const Navbar = () => {
    return (
        <div>
             <Routes>
             <Route path='/' element={
                    <Home />
                } />
                <Route path='/register' element={
                    <Registration />
                } />
                <Route path='/login' element={
                    <Login />
                } />
                 <Route path='/dashboard' element={
                    <Private Component={Dashboard}/>

                } />
                <Route path='/account' element={
                    <Account />
                } />
                <Route path='/logout' element={
                    <Logout />
                } />
             </Routes>
       
        </div>

    )
}

export default Navbar