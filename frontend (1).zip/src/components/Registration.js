import React,{useState} from 'react'
import axios from 'axios'
import { TextField, FormControl,Typography ,Button} from '@material-ui/core'
import HowToRegOutlinedIcon from '@mui/icons-material/HowToRegRounded';
import '../CSS/Registration.css'
import { useNavigate } from 'react-router-dom';
import {message} from 'antd'

const Registration = (props) => {
    const Navigate = useNavigate()
    const [name,setName] = useState('')
    const [email,setEmail] = useState('')
    const [password,setPassword] = useState('')
    

    const handleChange = (e) => {
        if(e.target.name === "name"){
            setName(e.target.value)
        }else if(e.target.name === "email"){
            setEmail(e.target.value)
        }else if(e.target.name === "password"){
            setPassword(e.target.value)
        }
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        const form = {
            name,
            email,
            password
        }
        console.log('1',form)
        axios.post('http://localhost:3077/api/register',form)
             .then((response)=>{
                const result = response.data
                if(result.hasOwnProperty('errors')){
                 message.error(result.message)
                }else{
                    message.success('sucessfully registration')
                    Navigate('/login')
                }
               
             })
             .catch((err)=>{
                alert(err.message)
             })
    }
    return (
        <div className='Registration'>
            <div>
                < HowToRegOutlinedIcon />
                <br />
                <Typography variant="h4" component="h4">
                    Registration with us
                </Typography>

            </div >
            <form className='form' onSubmit={handleSubmit}>
            <FormControl >
                <TextField type="text" label="Name" placeholder="Please Enter Your Name" value={name} name="name" onChange={handleChange} />
                <br />
                <TextField type="text" label="Email" placeholder="Please Enter Your Email" value={email} name="email" onChange={handleChange} />
                <br />
                <TextField type='password' label="Password" placeholder="Please Enter Your Password" value={password} name="password" onChange={handleChange} />
                <br />
             
                <div className='Button'>
                <Button type="submit">register</Button>
                </div>
            </FormControl>
            <p>If you are Already Register <a href='/login'> click here </a> to go login page</p>
            </form>
        </div>
    )
}

export default Registration